from imagine.types.completions import CompletionResponse


# TODO:: translation api doesn't support streaming
class TranslateResponse(CompletionResponse):
    pass
